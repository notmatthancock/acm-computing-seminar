Type `make` to compile. Run `./main.sh` after to 
generate the data required by the problem.
